# AGENT

# ShopAgent Builder

> **Identity:** Domain specialist for ShopAgent — the multi-agent e-commerce AI system built across the Semana AI Data Engineer 4-night event
> **Domain:** E-commerce data generation, RAG pipelines, autonomous agents, multi-agent crews, chat interfaces, evaluation
> **Default Threshold:** 0.90

---

## MANDATORY: Read Before Building

Before generating ANY ShopAgent component, read these KB files based on the day:

### Day 1: Data Generation + Models
1. `.claude/kb/shadowtraffic/patterns/ecommerce-postgres.md` — Full config for customers+products+orders→Postgres, reviews→JSONL
2. `.claude/kb/pydantic/concepts/base-model.md` — Pydantic models for e-commerce entities
3. `.claude/kb/shadowtraffic/concepts/functions.md` — _gen functions (uuid, lookup, faker)

### Day 2: RAG + Ledger
4. `.claude/kb/llamaindex/patterns/jsonl-to-qdrant.md` — **KEY**: JSONL→FastEmbed→Qdrant pipeline
5. `.claude/kb/qdrant/quick-reference.md` — Collection config, search API
6. `.claude/kb/supabase/quick-reference.md` — SQL queries via MCP

### Day 3: Agent + Chainlit
7. `.claude/kb/langchain/patterns/react-agent-dual-tools.md` — **KEY**: Dual-tool agent (SQL vs semantic)
8. `.claude/kb/chainlit/patterns/langchain-integration.md` — **KEY**: Streaming chat with step visibility
9. `.claude/kb/langchain/concepts/tools.md` — @tool definitions with routing docstrings

### Day 4: Multi-Agent + Eval + Cloud
10. `.claude/kb/crewai/concepts/agents.md` — Agent roles, goals, backstories
11. `.claude/kb/crewai/concepts/crews.md` — Crew composition
12. `.claude/kb/deepeval/patterns/agent-evaluation.md` — **KEY**: Evaluate tool routing + answer quality
13. `.claude/kb/langfuse/patterns/python-sdk-integration.md` — Observability traces

---

## Architecture: The Ledger + The Memory

```
                    +------------------+
                    |  ReporterAgent   |  Combines results
                    |  Goal: Executive |  into actionable
                    |  report          |  response
                    +--------+---------+
                             |
                    receives context
                             |
              +--------------+--------------+
              |                             |
    +---------+--------+          +---------+--------+
    |  AnalystAgent    |          |  ResearchAgent   |
    |  Role: SQL data  |          |  Role: Semantic  |
    |  Tool: Supabase  |          |  Tool: Qdrant    |
    |  (The Ledger)    |          |  (The Memory)    |
    +------------------+          +------------------+
```

**The Ledger (Supabase/Postgres):** Exact data — revenue, counts, averages, JOINs
**The Memory (Qdrant):** Meaning — complaints, sentiment, review themes

---

## Data Model

```
customers (Postgres)          products (Postgres)
├── customer_id: UUID         ├── product_id: UUID
├── name: VARCHAR             ├── name: VARCHAR
├── email: VARCHAR            ├── category: VARCHAR
├── city: VARCHAR             ├── price: DECIMAL
├── state: CHAR(2)            └── brand: VARCHAR
└── segment: VARCHAR

orders (Postgres)             reviews (JSONL → Qdrant)
├── order_id: UUID            ├── review_id: UUID
├── customer_id: UUID (FK)    ├── order_id: UUID (FK)
├── product_id: UUID (FK)     ├── rating: INT (1-5)
├── qty: INT                  ├── comment: TEXT
├── total: DECIMAL            └── sentiment: VARCHAR
├── status: VARCHAR
├── payment: VARCHAR
└── created_at: TIMESTAMPTZ
```

---

## Quick Reference

```text
┌─────────────────────────────────────────────────────────────┐
│  SHOPAGENT-BUILDER DECISION FLOW                             │
├─────────────────────────────────────────────────────────────┤
│  1. IDENTIFY DAY → What day's component is being built?      │
│  2. LOAD KB     → Read the day-specific KB files above       │
│  3. VALIDATE    → Query MCP if KB patterns insufficient      │
│  4. BUILD       → Generate code following KB patterns exactly │
│  5. VERIFY      → Check against data model and architecture  │
└─────────────────────────────────────────────────────────────┘
```

---

## Validation System

### Agreement Matrix

```text
                    │ MCP AGREES     │ MCP DISAGREES  │ MCP SILENT     │
────────────────────┼────────────────┼────────────────┼────────────────┤
KB HAS PATTERN      │ HIGH: 0.95     │ CONFLICT: 0.50 │ MEDIUM: 0.75   │
                    │ → Execute      │ → Investigate  │ → Proceed      │
────────────────────┼────────────────┼────────────────┼────────────────┤
KB SILENT           │ MCP-ONLY: 0.85 │ N/A            │ LOW: 0.50      │
                    │ → Proceed      │                │ → Ask User     │
────────────────────┴────────────────┴────────────────┴────────────────┘
```

### Task Thresholds

| Category | Threshold | Action If Below | Examples |
|----------|-----------|-----------------|----------|
| CRITICAL | 0.98 | REFUSE + explain | MCP connection configs, API keys |
| IMPORTANT | 0.95 | ASK user first | Agent routing logic, crew orchestration |
| STANDARD | 0.90 | PROCEED + disclaimer | Component generation, UI patterns |
| ADVISORY | 0.80 | PROCEED freely | Docs, comments, config tweaks |

---

## Capabilities

### Capability 1: ShadowTraffic Config (Day 1)

**When:** User needs e-commerce data generation config
**KB:** `.claude/kb/shadowtraffic/patterns/ecommerce-postgres.md`
**Output:** Complete `shadowtraffic.json` with schedule.stages, lookup FKs, faker expressions

### Capability 2: Pydantic Models (Day 1)

**When:** User needs typed e-commerce data models
**KB:** `.claude/kb/pydantic/concepts/base-model.md`
**Output:** Customer, Product, Order, Review BaseModel classes matching the data model above

### Capability 3: RAG Pipeline (Day 2)

**When:** User needs to ingest reviews into Qdrant
**KB:** `.claude/kb/llamaindex/patterns/jsonl-to-qdrant.md`
**Output:** Complete ingest + query pipeline using JSONReader, FastEmbed, QdrantVectorStore

### Capability 4: LangChain Agent (Day 3)

**When:** User needs autonomous agent with SQL/semantic routing
**KB:** `.claude/kb/langchain/patterns/react-agent-dual-tools.md`
**Output:** ReAct agent with supabase_execute_sql + qdrant_semantic_search tools

### Capability 5: Chainlit Interface (Day 3-4)

**When:** User needs chat UI for the agent
**KB:** `.claude/kb/chainlit/patterns/langchain-integration.md`
**Output:** Chainlit app with streaming + tool step visibility

### Capability 6: CrewAI Crew (Day 4)

**When:** User needs multi-agent crew
**KB:** `.claude/kb/crewai/concepts/agents.md`, `.claude/kb/crewai/concepts/crews.md`
**Output:** @CrewBase with AnalystAgent (Supabase) + ResearchAgent (Qdrant) + ReporterAgent

### Capability 7: Evaluation Suite (Day 4)

**When:** User needs to evaluate agent quality
**KB:** `.claude/kb/deepeval/patterns/agent-evaluation.md`
**Output:** Test matrix with ToolCorrectnessMetric + AnswerRelevancyMetric

---

## MCP Connections

```json
{
  "mcpServers": {
    "postgres": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-postgres",
               "postgresql://shopagent:shopagent@localhost:5432/shopagent"],
      "comment": "Day 4 cloud: replace with mcp-server-supabase"
    },
    "qdrant": {
      "command": "uvx",
      "args": ["mcp-server-qdrant"],
      "env": {
        "QDRANT_URL": "http://localhost:6333",
        "COLLECTION_NAME": "shopagent_reviews"
      }
    }
  }
}
```

---

## Quality Checklist

Run before completing any ShopAgent component:

```text
ARCHITECTURE
[ ] Uses The Ledger (Supabase) for exact data
[ ] Uses The Memory (Qdrant) for semantic search
[ ] Data model matches agenda specification (4 entities)
[ ] MCP connections configured correctly

CODE QUALITY
[ ] Production-ready Python 3.11+ with type hints
[ ] Real imports (not placeholders)
[ ] Error handling for MCP failures
[ ] Matches KB pattern code style

INTEGRATION
[ ] Compatible with Docker Compose (local Days 1-3)
[ ] URL-swappable for cloud (Day 4)
[ ] Tool docstrings precise enough for correct routing
[ ] Chainlit streaming works with astream_events v2
```

---

## Anti-Patterns

| Anti-Pattern | Why It's Bad | Do This Instead |
|--------------|--------------|-----------------|
| Hardcode localhost URLs | Breaks Day 4 cloud migration | Use env vars or config |
| Vague tool docstrings | Agent routes to wrong store | Precise WHEN/WHAT descriptions |
| Skip schedule.stages | Lookup fails on empty tables | Always seed parent tables first |
| FaithfulnessMetric without retrieval_context | Metric throws error | Populate from Qdrant search results |
| Agent in on_message | New agent per message, no state | Create in on_chat_start + user_session |

---

## Changelog

| Version | Date | Changes |
|---------|------|---------|
| 1.0.0 | 2026-04-12 | Initial agent: 7 capabilities covering Days 1-4 |

---

## Remember

> **"Two Legs: The Ledger for Facts, The Memory for Meaning"**

**Mission:** Build ShopAgent components that are production-ready, correctly integrated across the dual-store architecture, and follow the KB patterns exactly — because every line of code will be demonstrated live to hundreds of participants.

**When uncertain:** Ask. When confident: Act. Always cite KB sources.


# KNOWLEDGE


## pydantic.concepts.base-model

# BaseModel

> **Purpose**: Core building block for defining validated data schemas in Pydantic v2
> **Confidence**: 0.95
> **MCP Validated**: 2026-02-17

## Overview

BaseModel is the primary class in Pydantic for defining data models with automatic type validation,
serialization, and JSON Schema generation. In Pydantic v2, it uses a Rust-based core
(pydantic-core) for significantly faster validation. Models validate data on instantiation
and provide methods for dict/JSON serialization and schema introspection.

## The Pattern

```python
from pydantic import BaseModel, Field, ConfigDict
from typing import Optional
from datetime import datetime


class Invoice(BaseModel):
    """Schema for extracted invoice data."""
    model_config = ConfigDict(
        strict=False,           # allow type coercion
        str_strip_whitespace=True,
        validate_default=True,
    )

    invoice_number: str = Field(..., description="Unique invoice identifier")
    vendor_name: str = Field(..., min_length=1, description="Name of the vendor")
    total_amount: float = Field(..., gt=0, description="Total invoice amount")
    currency: str = Field(default="USD", pattern=r"^[A-Z]{3}$")
    issue_date: datetime = Field(..., description="Date the invoice was issued")
    line_items: list[str] = Field(default_factory=list)
    notes: Optional[str] = None
```

## Quick Reference

| Method | Input | Output | Notes |
|--------|-------|--------|-------|
| `Invoice(**data)` | kwargs | Invoice | Validates on creation |
| `Invoice.model_validate(d)` | dict | Invoice | Parse from dict |
| `Invoice.model_validate_json(s)` | JSON str | Invoice | Parse from JSON |
| `inv.model_dump()` | -- | dict | To dictionary |
| `inv.model_dump_json()` | -- | str | To JSON string |
| `inv.model_dump(exclude_none=True)` | -- | dict | Skip None fields |
| `Invoice.model_json_schema()` | -- | dict | JSON Schema output |
| `inv.model_copy(update={"currency": "EUR"})` | dict | Invoice | Clone with changes |

## Common Mistakes

### Wrong (Pydantic v1 syntax)

```python
class MyModel(BaseModel):
    class Config:
        orm_mode = True

    def dict(self, **kwargs):  # v1 method
        return super().dict(**kwargs)
```

### Correct (Pydantic v2 syntax)

```python
from pydantic import ConfigDict

class MyModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    def to_dict(self):
        return self.model_dump()
```

## ConfigDict Options

| Option | Default | Purpose |
|--------|---------|---------|
| `strict` | `False` | Disable type coercion when True |
| `str_strip_whitespace` | `False` | Strip whitespace from strings |
| `validate_default` | `False` | Validate default values |
| `from_attributes` | `False` | Allow ORM-style attribute access |
| `populate_by_name` | `False` | Allow population by field name or alias |
| `extra` | `"ignore"` | Handle extra fields: ignore, allow, forbid |

## Serialization for LLM Prompts

```python
import json

# Generate JSON Schema to include in LLM prompts
schema = Invoice.model_json_schema()
prompt_instruction = (
    f"Return valid JSON matching this schema:\n"
    f"{json.dumps(schema, indent=2)}"
)

# Parse LLM response back into validated model
llm_response = '{"invoice_number": "INV-001", ...}'
invoice = Invoice.model_validate_json(llm_response)
```

## Related

- [Field Types](../concepts/field-types.md)
- [Validators](../concepts/validators.md)
- [LLM Output Validation](../patterns/llm-output-validation.md)


## supabase.quick-reference

# Supabase Quick Reference

> Fast lookup tables. For code examples, see linked files.
> **MCP Validated:** 2026-02-19

## pgvector Operations

| Operation | SQL | Notes |
|-----------|-----|-------|
| Enable extension | `CREATE EXTENSION IF NOT EXISTS vector;` | Run once per database |
| Create vector column | `embedding vector(1536)` | Dimension must match model |
| Insert embedding | `INSERT INTO docs (embedding) VALUES ($1)` | Pass as array or vector literal |
| Cosine similarity | `1 - (a <=> b)` | Returns 0..1, higher = more similar |
| L2 distance | `a <-> b` | Lower = more similar |
| Inner product | `a <#> b` | Negative inner product |
| HNSW index | `USING hnsw (col vector_cosine_ops)` | Default choice, auto-optimizes |
| IVFFlat index | `USING ivfflat (col vector_cosine_ops) WITH (lists = 100)` | Lower memory, needs `lists` tuning |

## RLS Policy Syntax

| Component | Syntax | Example |
|-----------|--------|---------|
| Enable RLS | `ALTER TABLE t ENABLE ROW LEVEL SECURITY;` | Required before policies work |
| SELECT policy | `CREATE POLICY "name" ON t FOR SELECT USING (expr);` | `auth.uid() = user_id` |
| INSERT policy | `CREATE POLICY "name" ON t FOR INSERT WITH CHECK (expr);` | `auth.uid() = user_id` |
| UPDATE policy | `FOR UPDATE USING (expr) WITH CHECK (expr);` | Both USING and CHECK needed |
| DELETE policy | `CREATE POLICY "name" ON t FOR DELETE USING (expr);` | Only USING clause |
| Current user | `auth.uid()` | Returns UUID of authenticated user |
| JWT claims | `auth.jwt() ->> 'claim'` | Access custom claims |

## Edge Function Commands

| Command | Purpose |
|---------|---------|
| `supabase functions new <name>` | Create new Edge Function |
| `supabase functions serve` | Local development server |
| `supabase functions deploy <name>` | Deploy to production |
| `supabase secrets set KEY=value` | Set environment variable |
| `supabase secrets list` | List all secrets |

## Supabase CLI Cheat Sheet

| Command | Purpose |
|---------|---------|
| `supabase init` | Initialize local project |
| `supabase start` | Start local Supabase stack |
| `supabase stop` | Stop local stack |
| `supabase migration new <name>` | Create migration file |
| `supabase db reset` | Reset local DB, replay migrations |
| `supabase db push` | Push migrations to remote |
| `supabase db diff` | Diff schema changes |
| `supabase link --project-ref <ref>` | Link to remote project |

## Common Pitfalls

| Don't | Do |
|-------|-----|
| Disable RLS for convenience | Design proper policies per table |
| Use `service_role` key client-side | Use `anon` key client-side, `service_role` server-side |
| Store embeddings without an index | Add HNSW index immediately after table creation |
| Hardcode secrets in Edge Functions | Use `Deno.env.get('SECRET')` |
| Use text search for semantic queries | Use pgvector similarity with proper distance function |
| Skip migration files | Always use `supabase migration new` |

## Decision Matrix

| Use Case | Choose |
|----------|--------|
| Semantic/meaning-based search | pgvector cosine similarity |
| Keyword/exact match search | PostgreSQL full-text search (tsvector) |
| < 1M vectors, high recall needed | HNSW index |
| > 1M vectors, memory constrained | IVFFlat index |
| Custom API endpoint | Edge Function |
| Database-triggered logic | PostgreSQL function + trigger |
| Low-latency client messaging | Realtime Broadcast |
| Listen to DB changes | Realtime Postgres Changes |

## Related Documentation

| Topic | Path |
|-------|------|
| pgvector deep dive | `concepts/pgvector-fundamentals.md` |
| RLS patterns | `concepts/rls-policies.md` |
| Edge Functions | `concepts/edge-functions.md` |
| Full Index | `index.md` |


## langchain.concepts.tools

# Tools

> **Purpose**: Define callable tools that LangChain agents use for Supabase SQL and Qdrant semantic search
> **Confidence**: 0.95
> **MCP Validated**: 2026-04-12

## Overview

Tools are Python functions decorated with `@tool` that LangChain agents can invoke. The `docstring` is critical — the LLM reads it to decide WHEN to call each tool. For ShopAgent, two tools cover the dual-store architecture: `supabase_execute_sql` for exact data (The Ledger) and `qdrant_semantic_search` for meaning-based search (The Memory).

## The Pattern

```python
from langchain.tools import tool


@tool
def supabase_execute_sql(query: str) -> str:
    """Execute SQL query against Supabase Postgres for EXACT data.

    Use when the question asks for specific numbers, totals, or structured data:
    - Faturamento (revenue) by state, category, or period
    - Total de pedidos (order counts), ticket medio (average order value)
    - Payment method distribution, customer segment analysis
    - Any question requiring aggregation, GROUP BY, or JOINs
    """
    # Implementation: call MCP Supabase execute_sql
    return f"SQL Result for: {query}"


@tool
def qdrant_semantic_search(question: str) -> str:
    """Search customer reviews by MEANING using Qdrant vector database.

    Use when the question asks about opinions, complaints, or text patterns:
    - Reclamacoes (complaints) about delivery, quality, price
    - Customer sentiment (positive, negative, neutral)
    - Product feedback and review themes
    - Any question about what customers SAY or FEEL
    """
    # Implementation: call MCP Qdrant search
    return f"Semantic Result for: {question}"
```

## Quick Reference

| Param | Source | Description |
|-------|--------|-------------|
| `name` | Function name | `"supabase_execute_sql"` — LLM sees this |
| `description` | Docstring | **Routing logic** — LLM reads this to choose |
| `args_schema` | Type hints | Inferred from function signature |
| `return_direct` | Decorator param | `False` (default) — agent synthesizes final answer |

## Common Mistakes

### Wrong

```python
@tool
def search(query: str) -> str:
    """Search the database."""  # Too vague — LLM can't distinguish SQL vs semantic
    ...
```

### Correct

```python
@tool
def supabase_execute_sql(query: str) -> str:
    """Execute SQL for EXACT data: revenue, counts, averages, aggregations."""
    ...

@tool
def qdrant_semantic_search(question: str) -> str:
    """Search reviews by MEANING: complaints, sentiment, opinions, feedback."""
    ...
```

Precise docstrings are the #1 factor in correct tool routing.

## Related

- [Chat Models](../concepts/chat-models.md)
- [ReAct Agent](../concepts/react-agent.md)
- [Dual-Tool Pattern](../patterns/react-agent-dual-tools.md)


## langchain.patterns.react-agent-dual-tools

# ReAct Agent Dual Tools

> **Purpose**: ShopAgent LangChain agent with supabase + qdrant tools that autonomously routes SQL vs semantic queries
> **MCP Validated**: 2026-04-12

## When to Use

- Day 3 single-agent ShopAgent with autonomous query routing
- Demonstrating ReAct pattern with real MCP-connected tools
- Agent that decides: "this needs exact numbers" (SQL) vs "this needs meaning" (semantic)

## Implementation

```python
"""ShopAgent Day 3: ReAct agent with dual-store routing."""
from langchain_anthropic import ChatAnthropic
from langchain.tools import tool
from langgraph.prebuilt import create_react_agent


@tool
def supabase_execute_sql(query: str) -> str:
    """Execute SQL query against Supabase Postgres for EXACT data.

    Use when the question asks for specific numbers, totals, or structured data:
    - Faturamento (revenue) by state, category, or period
    - Total de pedidos (order counts), ticket medio (average order value)
    - Payment method distribution, customer segment analysis
    - Any question requiring aggregation, GROUP BY, or JOINs

    Args:
        query: SQL query string to execute against the shopagent database.
    """
    # In production: call MCP Supabase execute_sql tool
    # result = mcp_supabase.execute_sql(query=query)
    return f"[SQL] Executed: {query}"


@tool
def qdrant_semantic_search(question: str) -> str:
    """Search customer reviews by MEANING using Qdrant vector database.

    Use when the question asks about opinions, complaints, or text patterns:
    - Reclamacoes (complaints) about delivery, quality, price
    - Customer sentiment analysis (positive, negative, neutral)
    - Product feedback themes and review patterns
    - Any question about what customers SAY, THINK, or FEEL

    Args:
        question: Natural language question for semantic similarity search.
    """
    # In production: call MCP Qdrant search tool
    # result = mcp_qdrant.search(collection="shopagent_reviews", query=question)
    return f"[Semantic] Searched: {question}"


# Initialize Claude with deterministic routing
llm = ChatAnthropic(
    model="claude-sonnet-4-20250514",
    temperature=0,
    streaming=True,
)

# Create ReAct agent with both tools
agent = create_react_agent(
    model=llm,
    tools=[supabase_execute_sql, qdrant_semantic_search],
)


def ask(question: str) -> str:
    """Ask ShopAgent a question — it routes to the right store."""
    result = agent.invoke({
        "messages": [{"role": "user", "content": question}]
    })
    return result["messages"][-1].content


if __name__ == "__main__":
    # SQL routing — exact numbers
    print(ask("Qual o faturamento total por estado?"))
    # Agent thinks: "revenue by state = exact numbers" → supabase_execute_sql

    # Semantic routing — meaning-based search
    print(ask("Quais clientes reclamam de entrega?"))
    # Agent thinks: "complaints about delivery = text meaning" → qdrant_semantic_search

    # Hybrid — agent may call both tools sequentially
    print(ask("Qual o ticket medio dos clientes que reclamam de entrega no Sudeste?"))
    # Agent thinks: "find complainers (semantic) then calculate average (SQL)"
```

## Configuration

| Setting | Value | Description |
|---------|-------|-------------|
| `model` | `"claude-sonnet-4-20250514"` | Claude Sonnet for balanced speed/quality |
| `temperature` | `0` | Deterministic tool routing |
| `streaming` | `True` | Required for Chainlit integration |
| `max_iterations` | default (25) | Max ReAct loops before stopping |

## Example Usage

```python
# Day 3 demo questions — the agent routes each correctly:

# → supabase_execute_sql
ask("Quantos pedidos foram feitos por pix?")
ask("Top 5 produtos por faturamento")
ask("Distribuicao de clientes por segmento")

# → qdrant_semantic_search
ask("O que os clientes falam sobre qualidade?")
ask("Reviews negativos sobre frete")
ask("Clientes satisfeitos com o produto")
```

## See Also

- [LangGraph Routing](../patterns/langgraph-routing.md)
- [Tools](../concepts/tools.md)
- [Supabase Ledger Queries](../../supabase/patterns/shopagent-ledger-queries.md)
- [Chainlit Integration](../../chainlit/patterns/langchain-integration.md)


## chainlit.patterns.langchain-integration

# LangChain Integration

> **Purpose**: Wrap ShopAgent LangChain/LangGraph agent in Chainlit with streaming and step visibility
> **MCP Validated**: 2026-04-12

## When to Use

- Day 3-4 Chainlit interface for ShopAgent
- Connecting LangChain `create_react_agent` to a chat UI
- Showing tool calls (Supabase SQL, Qdrant search) as expandable steps
- Token-by-token streaming for responsive UX

## Implementation

```python
"""ShopAgent Chainlit app with LangChain agent streaming."""
import chainlit as cl
from langchain_anthropic import ChatAnthropic
from langchain.tools import tool
from langgraph.prebuilt import create_react_agent


@tool
def supabase_execute_sql(query: str) -> str:
    """Execute SQL for exact data: revenue, counts, averages."""
    return f"[SQL] {query}"


@tool
def qdrant_semantic_search(question: str) -> str:
    """Search reviews by meaning: complaints, sentiment, opinions."""
    return f"[Semantic] {question}"


@cl.on_chat_start
async def start():
    """Initialize ShopAgent and store in session."""
    llm = ChatAnthropic(
        model="claude-sonnet-4-20250514",
        temperature=0,
        streaming=True,
    )
    agent = create_react_agent(
        model=llm,
        tools=[supabase_execute_sql, qdrant_semantic_search],
    )
    cl.user_session.set("agent", agent)
    await cl.Message(
        content="ShopAgent conectado! Pergunte sobre vendas, clientes ou reviews."
    ).send()


@cl.on_message
async def main(message: cl.Message):
    """Stream agent response with tool step visibility."""
    agent = cl.user_session.get("agent")
    msg = cl.Message(content="")
    current_step = None

    async for event in agent.astream_events(
        {"messages": [{"role": "user", "content": message.content}]},
        version="v2",
    ):
        kind = event["event"]

        # Stream LLM tokens
        if kind == "on_chat_model_stream":
            token = event["data"]["chunk"].content
            if token:
                await msg.stream_token(token)

        # Show tool call as expandable step
        elif kind == "on_tool_start":
            current_step = cl.Step(
                name=event["name"],
                type="tool",
            )
            await current_step.__aenter__()
            current_step.input = str(event["data"].get("input", ""))

        # Close tool step with result
        elif kind == "on_tool_end":
            if current_step:
                current_step.output = str(event["data"].get("output", ""))
                await current_step.__aexit__(None, None, None)
                current_step = None

    await msg.send()
```

## Configuration

| Setting | Value | Description |
|---------|-------|-------------|
| `streaming` | `True` | Required on ChatAnthropic for token streaming |
| `astream_events version` | `"v2"` | LangGraph event streaming API version |
| `Step type` | `"tool"` | Shows wrench icon for tool calls |

## Example Usage

```bash
# Run the Chainlit app
chainlit run app.py -w

# The UI shows:
# 1. User types: "Qual o faturamento por estado?"
# 2. Step appears: [SQL Query] supabase_execute_sql
#    Input: "SELECT c.state, SUM(o.total)..."
#    Output: "SP: 127430, RJ: 89210..."
# 3. Streaming response: "O faturamento por estado é..."
```

## See Also

- [CrewAI Integration](../patterns/crewai-integration.md)
- [Lifecycle](../concepts/lifecycle.md)
- [LangChain ReAct Agent](../../langchain/patterns/react-agent-dual-tools.md)


## qdrant.quick-reference

# Qdrant Quick Reference

> **MCP Validated:** 2026-02-24

## REST API Endpoints

| Operation | Method | Endpoint |
|-----------|--------|----------|
| Create collection | PUT | `/collections/{name}` |
| Delete collection | DELETE | `/collections/{name}` |
| Upsert points | PUT | `/collections/{name}/points` |
| Search | POST | `/collections/{name}/points/search` |
| Delete points | POST | `/collections/{name}/points/delete` |
| Get point | GET | `/collections/{name}/points/{id}` |
| Collection info | GET | `/collections/{name}` |
| List collections | GET | `/collections` |

## Create Collection (3072 dims, cosine)
```json
PUT /collections/ai-sdr-kb
{ "vectors": { "size": 3072, "distance": "Cosine" } }
```

## Upsert Points
```json
PUT /collections/ai-sdr-kb/points
{ "points": [{ "id": "uuid-here", "vector": [0.1, 0.2, ...],
    "payload": { "content": "text", "product_id": "slug", "content_type": "description",
      "is_active": true, "version": 2 } }] }
```

## Search with Filter
```json
POST /collections/ai-sdr-kb/points/search
{ "vector": [0.1, 0.2, ...], "limit": 5, "score_threshold": 0.72,
  "filter": { "must": [
    { "key": "is_active", "match": { "value": true } },
    { "key": "product_id", "match": { "value": "bootcamp-zero-prod-claude-code" } }
  ] }, "with_payload": true }
```

## Delete by Filter
```json
POST /collections/ai-sdr-kb/points/delete
{ "filter": { "must": [
    { "key": "product_id", "match": { "value": "bootcamp-zero-prod-claude-code" } }
] } }
```

## n8n Qdrant Vector Store Node

### Credential Setup

- Type: `qdrantApi`
- URL: `https://{cluster-id}.{region}.gcp.cloud.qdrant.io:6333` (Cloud) or `http://localhost:6333`
- API Key: from Qdrant Cloud dashboard

### Insert Mode

- Operation: Insert Documents
- Collection: `ai-sdr-kb`
- Connects to: Embeddings sub-node (OpenAI)

### AI Agent Tool Mode

- Operation: Retrieve Documents (as Tool for AI Agent)
- Collection: `ai-sdr-kb`
- Top K: 5
- Connects to: AI Agent's tool connector

## Payload Filtering Operators

| Operator | Example |
| -------- | ------- |
| `match` (exact) | `{"key": "content_type", "match": {"value": "pricing"}}` |
| `range` | `{"key": "version", "range": {"gte": 2}}` |
| `must` (AND) | `{"must": [filter1, filter2]}` |
| `should` (OR) | `{"should": [filter1, filter2]}` |
| `must_not` (NOT) | `{"must_not": [filter1]}` |

## Quantization (Cost Optimization)

```json
PUT /collections/ai-sdr-kb
{ "vectors": { "size": 3072, "distance": "Cosine" },
  "quantization_config": { "scalar": { "type": "int8", "always_ram": true } } }
```

Scalar quantization: 4x compression, ~99% accuracy with rescoring.

## Payload Index Types
`keyword`, `integer`, `float`, `bool`, `geo`, `datetime`, `text` (full-text)

## Distance Metrics
Cosine (text), Euclidean (images), Dot Product (pre-normalized), Manhattan (sparse)


## shadowtraffic.patterns.ecommerce-postgres

# E-Commerce Postgres

> **Purpose**: Complete ShopAgent e-commerce data generation — customers+products+orders→Postgres, reviews→JSONL via schedule.stages
> **MCP Validated**: 2026-04-12

## When to Use

- ShopAgent Day 1 data pipeline setup
- Generating relational e-commerce data with foreign key dependencies
- Producing both structured (SQL-queryable) and unstructured (text for RAG) data
- Workshop environment with clean-reset capability

## Implementation

```json
{
  "generators": [
    {
      "topic": "customers",
      "table": "customers",
      "row": {
        "customer_id": { "_gen": "uuid" },
        "name": { "_gen": "string", "expr": "#{Name.fullName}" },
        "email": { "_gen": "string", "expr": "#{Internet.emailAddress}" },
        "city": { "_gen": "string", "expr": "#{Address.city}" },
        "state": {
          "_gen": "oneOf",
          "choices": ["SP", "RJ", "MG", "RS", "PR", "SC", "BA", "PE"]
        },
        "segment": {
          "_gen": "oneOf",
          "choices": ["premium", "standard", "basic"]
        }
      },
      "localConfigs": { "maxEvents": 500, "throttle": 0 }
    },
    {
      "topic": "products",
      "table": "products",
      "row": {
        "product_id": { "_gen": "uuid" },
        "name": { "_gen": "string", "expr": "#{Commerce.productName}" },
        "category": { "_gen": "string", "expr": "#{Commerce.department}" },
        "price": {
          "_gen": "uniformDistribution",
          "bounds": [19.90, 999.90],
          "decimals": 2
        },
        "brand": { "_gen": "string", "expr": "#{Company.name}" }
      },
      "localConfigs": { "maxEvents": 200, "throttle": 0 }
    },
    {
      "topic": "orders",
      "table": "orders",
      "row": {
        "order_id": { "_gen": "uuid" },
        "customer_id": {
          "_gen": "lookup",
          "topic": "customers",
          "path": ["row", "customer_id"]
        },
        "product_id": {
          "_gen": "lookup",
          "topic": "products",
          "path": ["row", "product_id"]
        },
        "qty": {
          "_gen": "uniformDistribution",
          "bounds": [1, 10],
          "decimals": 0
        },
        "total": {
          "_gen": "uniformDistribution",
          "bounds": [29.90, 999.90],
          "decimals": 2
        },
        "status": {
          "_gen": "weightedOneOf",
          "choices": ["delivered", "shipped", "processing", "cancelled"],
          "weights": [0.50, 0.20, 0.20, 0.10]
        },
        "payment": {
          "_gen": "weightedOneOf",
          "choices": ["pix", "credit_card", "boleto"],
          "weights": [0.45, 0.40, 0.15]
        },
        "created_at": { "_gen": "now" }
      },
      "localConfigs": { "throttle": 100 }
    },
    {
      "topic": "reviews",
      "directory": "/data/reviews",
      "data": {
        "review_id": { "_gen": "uuid" },
        "order_id": {
          "_gen": "lookup",
          "topic": "orders",
          "path": ["row", "order_id"]
        },
        "rating": {
          "_gen": "weightedOneOf",
          "choices": [1, 2, 3, 4, 5],
          "weights": [0.05, 0.10, 0.20, 0.30, 0.35]
        },
        "comment": { "_gen": "string", "expr": "#{Lorem.paragraph}" },
        "sentiment": {
          "_gen": "weightedOneOf",
          "choices": ["positive", "neutral", "negative"],
          "weights": [0.35, 0.30, 0.35]
        }
      },
      "localConfigs": { "throttle": 500 },
      "fileConfigs": { "fileName": "reviews.jsonl" }
    }
  ],
  "connections": {
    "pg": {
      "kind": "postgres",
      "connectionConfigs": {
        "host": "postgres",
        "port": 5432,
        "db": "shopagent",
        "username": "shopagent",
        "password": "shopagent"
      },
      "tablePolicy": "dropAndCreate"
    },
    "fs": {
      "kind": "fileSystem"
    }
  },
  "schedule": {
    "stages": [
      {
        "generators": ["customers", "products"],
        "comment": "Stage 0: Seed parent tables first (500 customers + 200 products)"
      },
      {
        "generators": ["orders", "reviews"],
        "comment": "Stage 1: Stream orders with FK lookups + reviews to JSONL"
      }
    ]
  }
}
```

## Configuration

| Entity | maxEvents | Throttle | Destination | Notes |
|--------|-----------|----------|-------------|-------|
| customers | 500 | 0ms | Postgres | Seeded in stage 0 |
| products | 200 | 0ms | Postgres | Seeded in stage 0 |
| orders | continuous | 100ms | Postgres | Streamed in stage 1 with lookup FKs |
| reviews | continuous | 500ms | JSONL file | Streamed in stage 1, ingested by LlamaIndex on Day 2 |

## Example Usage

```bash
# Dev mode — dry run to stdout
docker run --env-file .env \
  -v $(pwd)/shadowtraffic.json:/home/config.json \
  shadowtraffic/shadowtraffic:latest \
  --config /home/config.json --sample 10 --stdout

# Production — stream to Postgres + filesystem
docker run --env-file .env \
  -v $(pwd)/shadowtraffic.json:/home/config.json \
  -v reviews_data:/data/reviews \
  shadowtraffic/shadowtraffic:latest \
  --config /home/config.json
```

## See Also

- [Staged Seeding](../patterns/staged-seeding.md)
- [Connections](../concepts/connections.md)
- [Functions](../concepts/functions.md)
- [Faker Expressions](../concepts/faker-expressions.md)


## deepeval.patterns.agent-evaluation

# Agent Evaluation

> **Purpose**: Evaluate ShopAgent tool selection correctness and answer quality across SQL and semantic routing
> **MCP Validated**: 2026-04-12

## When to Use

- Day 4 quality validation before the live demo
- Testing that the agent routes SQL queries to `supabase_execute_sql`
- Testing that the agent routes semantic queries to `qdrant_semantic_search`
- Measuring response relevancy across a representative test matrix

## Implementation

```python
"""ShopAgent evaluation — tool routing and answer quality."""
from deepeval import evaluate
from deepeval.metrics import AnswerRelevancyMetric, ToolCorrectnessMetric
from deepeval.test_case import LLMTestCase, ToolCall

# ---------------------------------------------------------------------------
# Test matrix: ShopAgent queries covering SQL, semantic, and hybrid
# ---------------------------------------------------------------------------
TEST_MATRIX = [
    # SQL queries — exact numbers from Supabase
    {
        "input": "Qual o faturamento total por estado?",
        "actual_output": "SP: R$ 127.430, RJ: R$ 89.210, MG: R$ 68.440",
        "tools_called": [ToolCall(name="supabase_execute_sql")],
        "expected_tools": [ToolCall(name="supabase_execute_sql")],
    },
    {
        "input": "Quantos pedidos foram feitos por pix?",
        "actual_output": "1.847 pedidos pagos via pix (45% do total).",
        "tools_called": [ToolCall(name="supabase_execute_sql")],
        "expected_tools": [ToolCall(name="supabase_execute_sql")],
    },
    {
        "input": "Qual o ticket medio por segmento de cliente?",
        "actual_output": "Premium: R$ 487, Standard: R$ 234, Basic: R$ 112",
        "tools_called": [ToolCall(name="supabase_execute_sql")],
        "expected_tools": [ToolCall(name="supabase_execute_sql")],
    },
    # Semantic queries — meaning from Qdrant
    {
        "input": "Quais clientes reclamam de entrega?",
        "actual_output": "23 clientes com reclamacoes de entrega: atrasos, extravio, frete caro.",
        "retrieval_context": ["Demorou 15 dias.", "Nao recebi meu pedido.", "Frete caro demais."],
        "tools_called": [ToolCall(name="qdrant_semantic_search")],
        "expected_tools": [ToolCall(name="qdrant_semantic_search")],
    },
    {
        "input": "O que os clientes falam sobre qualidade dos produtos?",
        "actual_output": "Maioria positiva. 12% citam problemas com durabilidade.",
        "retrieval_context": ["Produto otimo!", "Qualidade boa pelo preco.", "Quebrou em 2 semanas."],
        "tools_called": [ToolCall(name="qdrant_semantic_search")],
        "expected_tools": [ToolCall(name="qdrant_semantic_search")],
    },
    {
        "input": "Qual o sentimento geral sobre o frete?",
        "actual_output": "67% negativo. Principais queixas: prazo e custo.",
        "retrieval_context": ["Frete caro demais.", "Chegou antes do previsto!", "Rastreamento nao funciona."],
        "tools_called": [ToolCall(name="qdrant_semantic_search")],
        "expected_tools": [ToolCall(name="qdrant_semantic_search")],
    },
]

# ---------------------------------------------------------------------------
# Build test cases and metrics
# ---------------------------------------------------------------------------
test_cases = [LLMTestCase(**case) for case in TEST_MATRIX]

tool_metric = ToolCorrectnessMetric(threshold=1.0)
relevancy_metric = AnswerRelevancyMetric(
    threshold=0.7,
    model="claude-sonnet-4-20250514",
    include_reason=True,
)

# ---------------------------------------------------------------------------
# Batch evaluation
# ---------------------------------------------------------------------------
results = evaluate(test_cases=test_cases, metrics=[tool_metric, relevancy_metric])

# Print summary
for tc in test_cases:
    expected = tc.expected_tools[0].name if tc.expected_tools else "—"
    actual = tc.tools_called[0].name if tc.tools_called else "—"
    routing = "PASS" if expected == actual else "FAIL"
    print(f"[{routing}] {tc.input[:50]}")
```

## Configuration

| Setting | Value | Description |
|---------|-------|-------------|
| `ToolCorrectnessMetric.threshold` | `1.0` | Binary — must route to exact tool |
| `AnswerRelevancyMetric.threshold` | `0.7` | Minimum relevancy score |
| `model` for LLM metrics | `"claude-sonnet-4-20250514"` | Match ShopAgent stack |
| `include_reason` | `True` | Get explanation in `metric.reason` |

## Example Usage

```python
# Single test case
from deepeval.metrics import ToolCorrectnessMetric
from deepeval.test_case import LLMTestCase, ToolCall

test = LLMTestCase(
    input="Faturamento por estado?",
    actual_output="SP: R$ 127.430...",
    tools_called=[ToolCall(name="supabase_execute_sql")],
    expected_tools=[ToolCall(name="supabase_execute_sql")],
)
metric = ToolCorrectnessMetric(threshold=1.0)
metric.measure(test)
print(f"Score: {metric.score}")  # 1.0 if correct tool
```

## See Also

- [pytest Integration](../patterns/pytest-integration.md)
- [Test Cases](../concepts/test-cases.md)
- [LangChain Dual Tools](../../langchain/patterns/react-agent-dual-tools.md)


## crewai.concepts.agents

# Agents

> **Purpose**: Define autonomous AI agents with roles, goals, and tools for ShopAgent e-commerce workflows
> **Confidence**: 0.95
> **MCP Validated**: 2026-02-17

## Overview

A CrewAI Agent is an LLM-powered autonomous unit defined by a role, goal, and backstory. Each agent can execute tasks, call external tools, query memory, make decisions, and delegate work to other agents. Agents are the building blocks of every crew.

## The Pattern

```python
from crewai import Agent

analyst = Agent(
    role="E-Commerce Data Analyst",
    goal="Extract precise revenue, order, and customer metrics via SQL queries",
    backstory=(
        "You are an expert SQL analyst specialized in e-commerce data. "
        "You query Supabase Postgres for exact numbers: revenue, order counts, "
        "payment distributions, and customer segment metrics. You never guess "
        "numbers — every figure comes from a SQL query result."
    ),
    tools=[supabase_tool],
    llm="anthropic/claude-sonnet-4-20250514",
    memory=True,
    verbose=True,
    max_iter=5,
    allow_delegation=False,
)
```

## Quick Reference

| Parameter | Type | Default | Notes |
| --------- | ---- | ------- | ----- |
| `role` | str | required | Agent's job title / function |
| `goal` | str | required | What the agent aims to achieve |
| `backstory` | str | required | Context for persona consistency |
| `tools` | list | `[]` | Tools available to the agent |
| `llm` | str/LLM | default | Model identifier or LLM instance |
| `memory` | bool | `False` | Enable agent-level memory |
| `verbose` | bool | `False` | Enable detailed logging |
| `max_iter` | int | `20` | Max reasoning iterations |
| `max_rpm` | int | `None` | Rate limit for API calls |
| `allow_delegation` | bool | `True` | Can delegate to other agents |
| `step_callback` | callable | `None` | Hook after each reasoning step |
| `function_calling_llm` | str | `None` | Separate LLM for tool calls |

## YAML Configuration

```yaml
# config/agents.yaml
analyst:
  role: "E-Commerce Data Analyst"
  goal: "Extract precise revenue, order, and customer metrics via SQL queries"
  backstory: >
    You are an expert SQL analyst specialized in e-commerce data.
    You query Supabase Postgres for exact numbers and never guess figures.
  max_iter: 5
  verbose: true

researcher:
  role: "Customer Experience Researcher"
  goal: "Surface customer sentiment and complaint themes from review vectors"
  backstory: >
    You search Qdrant for review embeddings and synthesize sentiment patterns,
    recurring complaints, and satisfaction drivers from customer feedback.
  max_iter: 5
  verbose: true
```

```python
from crewai import Agent, CrewBase, agent

@CrewBase
class ShopAgentCrew:
    agents_config = "config/agents.yaml"

    @agent
    def analyst(self) -> Agent:
        return Agent(
            config=self.agents_config["analyst"],
            tools=[supabase_tool],
        )

    @agent
    def researcher(self) -> Agent:
        return Agent(
            config=self.agents_config["researcher"],
            tools=[qdrant_tool],
        )
```

## Common Mistakes

### Wrong

```python
# Missing backstory leads to generic, unfocused responses
agent = Agent(
    role="Analyst",
    goal="Analyze things",
)
```

### Correct

```python
# Specific role, goal, and backstory produce focused behavior
agent = Agent(
    role="E-Commerce Data Analyst",
    goal="Return exact revenue totals and order counts from Supabase Postgres",
    backstory=(
        "You specialize in e-commerce SQL. You query orders, customers, and "
        "products tables to return precise figures — never estimates."
    ),
    tools=[supabase_tool],
    max_iter=5,
)
```

## Related

- [Tasks](../concepts/tasks.md)
- [Crews](../concepts/crews.md)
- [Tools](../concepts/tools.md)
- [ShopAgent Crew Pattern](../patterns/shopagent-crew.md)


## llamaindex.patterns.jsonl-to-qdrant

# JSONL to Qdrant

> **Purpose**: Ingest ShopAgent reviews JSONL → FastEmbed embeddings → Qdrant collection via LlamaIndex
> **MCP Validated**: 2026-04-12

## When to Use

- Day 2 RAG pipeline: loading ShadowTraffic-generated reviews into Qdrant
- Building semantic search over e-commerce review text
- Any JSONL-to-vector-store ingestion with local embeddings (no API key required)

## Implementation

```python
"""ShopAgent Day 2: Ingest reviews JSONL into Qdrant via LlamaIndex."""
import qdrant_client
from llama_index.core import VectorStoreIndex, StorageContext, Settings
from llama_index.embeddings.fastembed import FastEmbedEmbedding
from llama_index.vector_stores.qdrant import QdrantVectorStore
from llama_index.readers.json import JSONReader


def ingest_reviews(
    jsonl_path: str = "./data/reviews/reviews.jsonl",
    qdrant_url: str = "http://localhost:6333",
    collection_name: str = "shopagent_reviews",
) -> VectorStoreIndex:
    """Load JSONL reviews, embed with FastEmbed, store in Qdrant.

    Args:
        jsonl_path: Path to ShadowTraffic-generated reviews JSONL.
        qdrant_url: Qdrant server URL (local Docker or cloud).
        collection_name: Target Qdrant collection name.

    Returns:
        VectorStoreIndex ready for querying.
    """
    # 1. Configure local embeddings (768 dims, no API key needed)
    Settings.embed_model = FastEmbedEmbedding(model_name="BAAI/bge-base-en-v1.5")

    # 2. Load JSONL — one Document per review line
    reader = JSONReader(is_jsonl=True, clean_json=True)
    documents = reader.load_data(input_file=jsonl_path)
    print(f"Loaded {len(documents)} reviews from {jsonl_path}")

    # 3. Connect to Qdrant
    client = qdrant_client.QdrantClient(url=qdrant_url)
    vector_store = QdrantVectorStore(
        client=client,
        collection_name=collection_name,
    )
    storage_context = StorageContext.from_defaults(vector_store=vector_store)

    # 4. Build index — embeds all documents and stores in Qdrant
    index = VectorStoreIndex.from_documents(
        documents,
        storage_context=storage_context,
        show_progress=True,
    )
    print(f"Indexed {len(documents)} reviews into Qdrant collection '{collection_name}'")

    return index


def query_reviews(
    question: str,
    qdrant_url: str = "http://localhost:6333",
    collection_name: str = "shopagent_reviews",
    top_k: int = 5,
) -> str:
    """Query existing Qdrant collection without re-indexing."""
    Settings.embed_model = FastEmbedEmbedding(model_name="BAAI/bge-base-en-v1.5")
    client = qdrant_client.QdrantClient(url=qdrant_url)
    vector_store = QdrantVectorStore(client=client, collection_name=collection_name)

    # Load from existing — NO re-embedding
    index = VectorStoreIndex.from_vector_store(vector_store)
    query_engine = index.as_query_engine(similarity_top_k=top_k)
    response = query_engine.query(question)

    return str(response)


if __name__ == "__main__":
    # Ingest
    index = ingest_reviews()

    # Query
    engine = index.as_query_engine(similarity_top_k=5)
    response = engine.query("Clientes reclamando de entrega")
    print(f"\nAnswer: {response.response}")
    print(f"\nSources ({len(response.source_nodes)} chunks):")
    for node in response.source_nodes:
        print(f"  [{node.score:.3f}] {node.text[:80]}...")
```

## Configuration

| Setting | Value | Description |
|---------|-------|-------------|
| `collection_name` | `"shopagent_reviews"` | Qdrant collection for reviews |
| `embed_model` | `BAAI/bge-base-en-v1.5` | 768 dims, local, no API key |
| `similarity_top_k` | `5` | Chunks retrieved per query |
| `qdrant_url` (local) | `http://localhost:6333` | Docker Qdrant (Days 1-3) |
| `qdrant_url` (cloud) | `https://xxx.cloud.qdrant.io:6333` | Qdrant Cloud (Day 4) |

## Example Usage

```python
# Day 2: Ingest + query
index = ingest_reviews("./data/reviews/reviews.jsonl")
engine = index.as_query_engine(similarity_top_k=5)

# Semantic search examples
print(engine.query("Clientes reclamando de entrega"))
print(engine.query("Reviews positivos sobre qualidade"))
print(engine.query("Problemas com pagamento via boleto"))
```

## See Also

- [RAG Query Pipeline](../patterns/rag-query-pipeline.md)
- [VectorStoreIndex](../concepts/vector-store-index.md)
- [Qdrant Reviews Collection](../../qdrant/patterns/shopagent-reviews-collection.md)


## crewai.concepts.crews

# Crews

> **Purpose**: Compose teams of agents that collaborate to solve ShopAgent e-commerce analysis
> **Confidence**: 0.95
> **MCP Validated**: 2026-02-17

## Overview

A Crew is a team of agents working together on a list of tasks through a defined process. Crews are the primary execution unit in CrewAI. You configure agents, tasks, process type, memory, and callbacks, then call `kickoff()` to run the workflow. Crews can be defined in Python or declaratively via YAML with the `@CrewBase` decorator.

## The Pattern

```python
from crewai import Agent, Task, Crew, Process

analyst = Agent(
    role="E-Commerce Data Analyst",
    goal="Extract revenue and order metrics via SQL",
    backstory="Expert SQL analyst querying Supabase for exact e-commerce figures.",
    tools=[supabase_tool],
    llm="anthropic/claude-sonnet-4-20250514",
)
researcher = Agent(
    role="Customer Experience Researcher",
    goal="Surface sentiment and complaint themes from review vectors",
    backstory="Searches Qdrant embeddings to identify recurring customer issues.",
    tools=[qdrant_tool],
    llm="anthropic/claude-sonnet-4-20250514",
)
reporter = Agent(
    role="Executive Report Writer",
    goal="Synthesize SQL metrics and review insights into an actionable report",
    backstory="Combines structured data and qualitative feedback into clear briefs.",
    llm="anthropic/claude-sonnet-4-20250514",
)

analysis_task = Task(
    description="Query revenue totals and order counts for {time_period}",
    expected_output="Revenue, order count, and top customer segments by SQL result",
    agent=analyst,
)
research_task = Task(
    description="Search reviews for sentiment and complaints in {time_period}",
    expected_output="Top complaint themes and satisfaction drivers with evidence",
    agent=researcher,
    context=[analysis_task],
)
report_task = Task(
    description="Write an executive e-commerce report combining metrics and sentiment",
    expected_output="Structured report with revenue, sentiment, and recommendations",
    agent=reporter,
    context=[analysis_task, research_task],
)

crew = Crew(
    agents=[analyst, researcher, reporter],
    tasks=[analysis_task, research_task, report_task],
    process=Process.sequential,
    memory=True,
    verbose=True,
)

result = crew.kickoff(inputs={"time_period": "last 30 days"})
print(result.raw)
```

## Quick Reference

| Parameter | Type | Default | Notes |
|-----------|------|---------|-------|
| `agents` | list[Agent] | required | Participating agents |
| `tasks` | list[Task] | required | Tasks to execute |
| `process` | Process | `sequential` | Execution strategy |
| `memory` | bool | `False` | Enable crew memory |
| `cache` | bool | `True` | Cache tool results |
| `verbose` | bool | `False` | Detailed logging |
| `max_rpm` | int | `None` | Global rate limit |
| `manager_llm` | str | `None` | LLM for hierarchical manager |
| `manager_agent` | Agent | `None` | Custom manager agent |
| `planning` | bool | `False` | Enable auto-planning |
| `embedder` | dict | `None` | Custom embedder config |
| `output_log_file` | str | `None` | Save execution logs |
| `step_callback` | callable | `None` | Hook after each step |
| `task_callback` | callable | `None` | Hook after each task |

## YAML Configuration (@CrewBase)

```python
from crewai import CrewBase, agent, task, crew, Agent, Task, Crew, Process

@CrewBase
class ShopAgentCrew:
    agents_config = "config/agents.yaml"
    tasks_config = "config/tasks.yaml"

    @agent
    def analyst(self) -> Agent:
        return Agent(config=self.agents_config["analyst"], tools=[supabase_tool])

    @agent
    def researcher(self) -> Agent:
        return Agent(config=self.agents_config["researcher"], tools=[qdrant_tool])

    @agent
    def reporter(self) -> Agent:
        return Agent(config=self.agents_config["reporter"])

    @crew
    def crew(self) -> Crew:
        return Crew(agents=self.agents, tasks=self.tasks, process=Process.sequential, memory=True)
```

> Full YAML config: see [patterns/yaml-configuration.md](../patterns/yaml-configuration.md)

## Execution Methods

| Method | Use Case |
|--------|----------|
| `kickoff(inputs={})` | Standard sync execution |
| `kickoff_for_each(inputs=[])` | Batch processing multiple inputs |
| `akickoff(inputs={})` | Async execution |

## Common Mistakes

### Wrong

```python
# Hierarchical process without manager LLM
crew = Crew(agents=[a1, a2], tasks=[t1], process=Process.hierarchical)
```

### Correct

```python
crew = Crew(
    agents=[a1, a2],
    tasks=[t1],
    process=Process.hierarchical,
    manager_llm="anthropic/claude-sonnet-4-20250514",
)
```

## Related

- [Agents](../concepts/agents.md)
- [Tasks](../concepts/tasks.md)
- [Processes](../concepts/processes.md)
- [ShopAgent Crew Pattern](../patterns/shopagent-crew.md)


## langfuse.patterns.python-sdk-integration

# Python SDK Integration

> **Purpose**: Complete setup guide for the Langfuse Python SDK with decorators and context managers
> **MCP Validated**: 2026-02-17

## When to Use

- Instrumenting any Python LLM application for observability
- Adding tracing, cost tracking, and scoring to existing pipelines
- Setting up Langfuse for the first time in a project

## Implementation

```python
"""Langfuse Python SDK integration - complete setup."""

import os
from langfuse import get_client, observe, propagate_attributes

# ── 1. Environment Variables ──────────────────────────────────
# Set in .env or deployment config:
# LANGFUSE_SECRET_KEY=sk-lf-...
# LANGFUSE_PUBLIC_KEY=pk-lf-...
# LANGFUSE_BASE_URL=https://cloud.langfuse.com

# ── 2. Client Initialization ─────────────────────────────────
langfuse = get_client()

# Verify connection
assert langfuse.auth_check(), "Langfuse authentication failed"


# ── 3. Decorator-Based Tracing ────────────────────────────────
@observe()
def preprocess_document(document: dict) -> dict:
    """Automatically traced as a span. Input/output captured."""
    cleaned = document.copy()
    cleaned["text"] = cleaned["text"].strip()
    return cleaned


@observe(as_type="generation")
def extract_fields(text: str, model: str = "gemini-2.0-flash") -> dict:
    """Traced as a generation. Captures model, tokens, cost."""
    # Your LLM call here
    response = llm_client.generate(
        prompt=f"Extract invoice fields from: {text}",
        model=model,
        temperature=0.0
    )
    return response


@observe()
def process_invoice(document: dict) -> dict:
    """Top-level function creates the trace. Nested calls auto-nest."""
    cleaned = preprocess_document(document)
    result = extract_fields(cleaned["text"])
    return result


# ── 4. Context Manager Tracing ────────────────────────────────
def process_with_context(document: dict) -> dict:
    """Manual tracing with context managers for fine-grained control."""
    with langfuse.start_as_current_observation(
        as_type="span",
        name="process-invoice"
    ) as root:
        root.update(
            input=document,
            metadata={"source": "api"}
        )

        with propagate_attributes(
            user_id=document.get("user_id", "unknown"),
            session_id=document.get("session_id"),
            tags=["invoice-extraction"]
        ):
            # Nested generation
            with langfuse.start_as_current_observation(
                as_type="generation",
                name="extract-fields",
                model="gemini-2.0-flash"
            ) as gen:
                result = llm_client.generate(document["text"])
                gen.update(
                    input=document["text"],
                    output=result,
                    usage_details={"input": 500, "output": 120},
                    cost_details={"total": 0.001}
                )

        root.update(output=result)

    langfuse.flush()
    return result


# ── 5. Scoring During Execution ───────────────────────────────
@observe(as_type="generation")
def extract_and_score(text: str) -> dict:
    """Extract fields and score the result inline."""
    with langfuse.start_as_current_observation(
        as_type="generation",
        name="scored-extraction",
        model="gemini-2.0-flash"
    ) as gen:
        result = llm_client.generate(text)
        gen.update(output=result)

        # Score this generation
        gen.score(
            name="has_required_fields",
            value=1 if all_fields_present(result) else 0,
            data_type="BOOLEAN"
        )
    return result
```

## Configuration

| Setting | Default | Description |
|---------|---------|-------------|
| `LANGFUSE_SECRET_KEY` | None | Server-side API key |
| `LANGFUSE_PUBLIC_KEY` | None | Client-side API key |
| `LANGFUSE_BASE_URL` | `https://cloud.langfuse.com` | API endpoint (EU) |
| `LANGFUSE_TRACING_ENVIRONMENT` | None | Environment label (production/staging) |
| `LANGFUSE_OBSERVE_DECORATOR_IO_CAPTURE_ENABLED` | `true` | Capture function I/O |

## Example Usage

```python
# Minimal setup - just decorate your functions
from langfuse import observe

@observe()
def my_pipeline(input_text: str) -> str:
    preprocessed = clean_text(input_text)
    result = call_llm(preprocessed)
    return result

@observe(as_type="generation")
def call_llm(text: str) -> str:
    return llm.generate(text)

# Run - traces are created automatically
output = my_pipeline("Extract fields from this invoice...")
```

## Disabling I/O Capture

```python
# For large inputs/outputs, disable capture to reduce overhead
@observe(capture_input=False, capture_output=False)
def process_large_document(large_text: str) -> dict:
    return extract(large_text)
```

## See Also

- [Traces and Spans](../concepts/traces-spans.md)
- [Generations](../concepts/generations.md)
- [Cloud Run Instrumentation](../patterns/cloud-run-instrumentation.md)


## shadowtraffic.concepts.functions

# Functions

> **Purpose**: Built-in _gen functions that produce realistic synthetic values
> **Confidence**: 0.95
> **MCP Validated**: 2026-04-12

## Overview

Every field in a ShadowTraffic generator uses `{"_gen": "functionName", ...params}` to produce data. Functions range from simple scalars (uuid, boolean) to relational references (lookup) and text generation (string with Faker expressions). Function modifiers like `decimals` and `cast` control output formatting.

## The Pattern

```json
{
  "table": "orders",
  "vars": {
    "customerId": { "_gen": "lookup", "topic": "customers", "path": ["row", "customer_id"] }
  },
  "row": {
    "order_id": { "_gen": "uuid" },
    "customer_id": { "_gen": "var", "var": "customerId" },
    "total": { "_gen": "uniformDistribution", "bounds": [29.90, 999.90], "decimals": 2 },
    "qty": { "_gen": "uniformDistribution", "bounds": [1, 10], "decimals": 0 },
    "status": {
      "_gen": "weightedOneOf",
      "choices": ["delivered", "shipped", "processing", "cancelled"],
      "weights": [0.50, 0.20, 0.20, 0.10]
    },
    "payment": { "_gen": "oneOf", "choices": ["pix", "credit_card", "boleto"] },
    "note": { "_gen": "string", "expr": "Order for #{Name.firstName}" },
    "created_at": { "_gen": "now" }
  }
}
```

## Quick Reference

| Function | Required Params | Output | Notes |
|----------|----------------|--------|-------|
| `uuid` | — | UUID string | `"a1b2c3d4-..."` |
| `oneOf` | `choices[]` | Random element | Uniform distribution |
| `weightedOneOf` | `choices[]`, `weights[]` | Weighted pick | Weights must sum to 1.0 |
| `uniformDistribution` | `bounds:[min,max]` | Random float | Use `decimals` to control precision |
| `normalDistribution` | `mean`, `sd` | Gaussian float | Bell curve around mean |
| `lookup` | `topic`, `path[]` | Value from another generator | FK reference — path varies by connection |
| `string` | `expr` | Faker-templated text | Uses `#{Namespace.method}` syntax |
| `var` | `var` | Named variable value | Reference `vars` block in same generator |
| `now` | `offset` (optional) | ISO timestamp | Offset in ms (e.g., -86400000 = yesterday) |
| `boolean` | — | true/false | Random boolean |
| `sequentialInteger` | `start` (optional) | Auto-increment int | Starts at 0 by default |

## Lookup Path by Connection Type

| Connection | Path Format | Example |
|------------|-------------|---------|
| Postgres | `["row", "field_name"]` | `["row", "customer_id"]` |
| Kafka | `["value", "field_name"]` | `["value", "user_id"]` |
| Filesystem | `["data", "field_name"]` | `["data", "order_id"]` |

**This is the #1 mistake.** The `path` must start with the shape key of the referenced generator.

## Common Mistakes

### Wrong

```json
{ "_gen": "lookup", "topic": "customers", "path": "customer_id" }
```

Path must be an array starting with the shape key, not a plain string.

### Correct

```json
{ "_gen": "lookup", "topic": "customers", "path": ["row", "customer_id"] }
```

Array path: `["row", "customer_id"]` for Postgres generators.

## Related

- [Faker Expressions](../concepts/faker-expressions.md)
- [Generators](../concepts/generators.md)
- [Staged Seeding](../patterns/staged-seeding.md)



# OBJECTIVE

Create Pydantic models for ShopAgent