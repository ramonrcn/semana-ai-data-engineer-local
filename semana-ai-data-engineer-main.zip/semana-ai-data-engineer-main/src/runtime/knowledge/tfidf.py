from sklearn.feature_extraction.text import TfidfVectorizer

from .selector import BaseKnowledgeSelector


class TFIDFKnowledgeSelector(BaseKnowledgeSelector):

    def select(
        self,
        documents,
        objective: str = "",
    ):

        corpus = [
            document.content
            for document in documents
        ]

        vectorizer = TfidfVectorizer(
            stop_words="english"
        )

        tfidf = vectorizer.fit_transform(
            corpus + [objective]
        )

        objective_vector = tfidf[-1]

        document_vectors = tfidf[:-1]

        scores = (
            document_vectors
            @ objective_vector.T
        ).toarray().ravel()

        ranked_documents = sorted(
            zip(documents, scores),
            key=lambda item: item[1],
            reverse=True,
        )

        # Display the effective query terms recognized by TF-IDF.
        print("\n=== TF-IDF QUERY TERMS ===")

        query_terms = sorted(
            set(vectorizer.build_analyzer()(objective))
        )

        print(query_terms)

        # Display document ranking scores.
        print("\n=== TF-IDF SCORES ===")

        for document, score in ranked_documents:

            print(
                f"{score:.4f} | {document.id}"
            )

        return [
            document
            for document, _ in ranked_documents
        ]