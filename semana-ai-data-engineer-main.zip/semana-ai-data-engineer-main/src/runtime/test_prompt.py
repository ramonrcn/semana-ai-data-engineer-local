from pathlib import Path

from .testing import (
    build_test_runtime
)

from .registry import (
    CapabilityRegistry
)

from .knowledge.registry import (
    KnowledgeRegistry
)

from .runtime import (
    AgentRuntime
)


# Build Capability Registry
cap_registry = CapabilityRegistry()

cap_registry.load_directory(
    Path(".claude/agents")
)


# Build Knowledge Registry
kb_registry = KnowledgeRegistry()

kb_registry.load_directory(
    Path(".claude/kb")
)


from .knowledge.tfidf import (
    TFIDFKnowledgeSelector
)

runtime = build_test_runtime(
    selector=TFIDFKnowledgeSelector()
)

# Build execution context
context = runtime.build_context(
    "domain.shopagent-builder"
)


print("\n" + "=" * 80)
print("CAPABILITY")
print("=" * 80)

print(
    context.capability.id
)


# Display all knowledge documents loaded into the runtime context
print("\n" + "=" * 80)
print("KNOWLEDGE DOCUMENTS")
print("=" * 80)

total_chars = 0

for document in context.knowledge:

    chars = len(
        document.content
    )

    total_chars += chars

    print(
        f"{document.id:<60} {chars:>8} chars"
    )


print("\n" + "=" * 80)
print("KNOWLEDGE SUMMARY")
print("=" * 80)

print(
    f"Documents loaded : {len(context.knowledge)}"
)

print(
    f"Knowledge size   : {total_chars:,} chars"
)


# Assemble the final prompt exactly as it will be sent to the model
prompt = runtime.assemble_prompt(
    "domain.shopagent-builder",
    "Create Pydantic models for ShopAgent"
)


# Persist the compiled prompt for offline inspection
artifacts = Path(
    "artifacts"
)

artifacts.mkdir(
    exist_ok=True
)

prompt_path = (
    artifacts /
    "compiled_prompt.md"
)

prompt_path.write_text(
    prompt,
    encoding="utf-8"
)


print("\n" + "=" * 80)
print("PROMPT SUMMARY")
print("=" * 80)

print()

print(
    f"Knowledge Selector: "
    f"{runtime.knowledge_selector.__class__.__name__}"
)

print(
    f"Prompt size      : {len(prompt):,} chars"
)

print(
    f"Prompt file      : {prompt_path}"
)

print(
    f"Knowledge ratio  : {total_chars / len(prompt):.1%}"
)